#dual_autodiff/__init__.py

from dual_autodiff_x.dual import Dual

# Print version
print(f"Cythonized Automatic Differentiation Package version: 0.0.8")